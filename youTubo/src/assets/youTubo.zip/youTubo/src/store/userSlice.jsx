import { createSlice } from "@reduxjs/toolkit";


const userSlice = createSlice({
    name: "user",
    initialState: {
        username: "suprith",
        userInfo: null,
        ismenuToggle: false,
        iswatchPage: false,


    },
    reducers: {
        addUser: (state, action) => {
            state.username = action.payload;
        },
        userInfo: (state, action) => {
            state.userInfo = action.payload;
        },
        menuToggle: (state, action) => {
            state.ismenuToggle = !state.ismenuToggle;
        },
        hideMenu: (state, action) => {
            state.ismenuToggle = action.payload;
        },
        watchPage: (state, action) => {
            state.iswatchPage = action.payload;
        },
    }
})

export default userSlice.reducer;
export const { addUser, menuToggle, watchPage, hideMenu, userInfo } = userSlice.actions;