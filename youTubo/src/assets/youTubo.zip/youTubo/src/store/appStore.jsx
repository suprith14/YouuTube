import { configureStore } from "@reduxjs/toolkit";
import userSliceReducer from "./userSlice";
import movieSliceReducer from "./movieSlice";
import languageSliceReducer from "./languageSlice";



const appStore = configureStore({
    reducer: {
        user: userSliceReducer,
        movie: movieSliceReducer,
        language: languageSliceReducer,

    }
})

export default appStore;