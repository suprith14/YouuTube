import React from 'react'
import Header from '../components/Header'
import MenuDrawer from '../components/MenuDrawer'
import { useSelector } from 'react-redux'
import { Outlet } from 'react-router-dom'

const HomePage = () => {
    const isToggle = useSelector((state) => state.user?.ismenuToggle)
    const iswatchPage = useSelector((state) => state.user?.iswatchPage);
    return (
        <div className='relative'>
            <Header />
            <div className='flex justify-center'>
                {isToggle &&
                    <div className={` ${iswatchPage ? "absolute top-30 left-0 z-10 bg-white" : ""} `}>
                        <MenuDrawer />
                    </div>}
                <div className=''>
                    <Outlet />
                </div>
            </div>
        </div>
    )
}
export default HomePage
