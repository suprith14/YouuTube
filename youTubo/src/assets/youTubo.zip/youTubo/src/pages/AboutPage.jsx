import React from 'react'

const AboutPage = () => {
    return (
        <div>
            About Page
            <iframe width="560" height="315" src="https://www.youtube.com/embed/QmfyWw3Cth8?si=s47LlyPTJxRkYL-6" title="YouTube video player" frameBorder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerPolicy="strict-origin-when-cross-origin" allowFullScreen></iframe>

        </div>
    )
}

export default AboutPage
