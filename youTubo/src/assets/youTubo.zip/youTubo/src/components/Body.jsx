import React, { useEffect, useState } from 'react'
import { VEDIOCATEGORIES_API, YOUTUBE_API_URL } from '../utils/constants';
import VedioCard from './VedioCard';
import { useDispatch, useSelector } from 'react-redux';
import { addPopularMovies } from '../store/movieSlice';
import { languageCon } from '../utils/languageConstents';
import { Link } from 'react-router-dom';
import { watchPage } from '../store/userSlice';

const Body = () => {
    const [movieData, setMovieData] = useState([])

    const dispatch = useDispatch();

    const language11 = useSelector((state) => state.language?.selectedLanguage);

    dispatch(watchPage(false));

    const getPopularVedios = async () => {
        const data = await fetch(YOUTUBE_API_URL);
        const json = await data.json();
        dispatch(addPopularMovies(json.items));
        setMovieData(json.items);
    }
    useEffect(() => {
        getPopularVedios()
    }, [])
    const toptab = [languageCon[language11]?.All,
    languageCon[language11]?.Music,
    languageCon[language11]?.Movies,
    languageCon[language11]?.News,
    languageCon[language11]?.Gaming,
    languageCon[language11]?.Live,
    languageCon[language11]?.Trending,
    ]

    const getVedioCategory = async () => {
        const data = await fetch(VEDIOCATEGORIES_API);
        const json = await data.json();
        console.log("VEDIO CATEGORIES : ", json)
    }

    useEffect(() => {
        getVedioCategory();
    }, [])
    return (<>
        <div className='flex flex-row ml-10'>
            {toptab?.map((tab) => { return (<div key={tab} className='text-center text-sm font-bold mx-2 px-10 py-2 shadow-md hover:bg-gray-200 cursor-pointer'>{tab}</div>) })}
        </div>
        <div className='ml-8'>
            <div className='flex flex-wrap flex-row justify-between '>
                {movieData?.map((movie) => {
                    return (
                        <Link to={`watch?id=${movie.id.videoId}`} key={movie.etag}>
                            <VedioCard key={movie.etag} movie={movie} />
                        </Link>
                    )
                })}
            </div>
        </div>
    </>
    )
}
export default Body
