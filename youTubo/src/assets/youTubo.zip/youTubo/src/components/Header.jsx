import React, { useEffect, useState } from 'react'
import menu from '../assets/menu.png'
import logo from '../assets/youtube_logo1.jpg'
import { useDispatch, useSelector } from 'react-redux'
import { menuToggle, userInfo } from '../store/userSlice'
import { languageSelect } from '../utils/languageConstents'
import { addSelectedLanguage } from '../store/languageSlice'
import { YOUTUBE_API_KEY } from '../utils/constants'
import { getAuth, signOut } from "firebase/auth";
import { useNavigate } from 'react-router-dom'
import userPhoto from '../assets/user11.svg'
import menu11 from '../assets/menu11.svg'
import search11 from '../assets/search11.svg'
import logout11 from '../assets/logout11.svg'
import { languageCon } from '../utils/languageConstents'
const Header = () => {
    const [searchSugestion, setSearchSuggestion] = useState(false)
    const [inputValue, setInputValue] = useState('')
    const [searchSuggestionData, setSearchSuggestionData] = useState([])

    const dispatch = useDispatch()
    const navigate = useNavigate()

    const user = useSelector((state) => state.user.userInfo)
    const language11 = useSelector((state) => state.language?.selectedLanguage);
    useEffect(() => {
        if (!user) {
            navigate("/login")
        }


    }, [])



    const handleToggle = () => {
        dispatch(menuToggle())
    }
    const handelLanguageChange = (e) => {
        dispatch((addSelectedLanguage(e.target.value)))
    }
    const handleInputChange = (e) => {
        setInputValue(e.target.value)
        if (e.target.value.length > 0) {
            setSearchSuggestion(true)
        } else {
            setSearchSuggestion(false)
        }
    }
    const getsuggestion = async () => {
        const data = await fetch(`https://suggestqueries.google.com/complete/search?client=chrome&q=${inputValue}`)
        // const data = await fetch(`https://youtube.googleapis.com/youtube/v3/search?part=snippet&maxResults=25&q=${inputValue}&key=${YOUTUBE_API_KEY}`)
        const json = await data.json();
        setSearchSuggestionData(json[1])
    }
    useEffect(() => {
        try {
            if (inputValue) {
                getsuggestion()
            }
        }
        catch (error) {
        }
    }, [inputValue])

    const handlesearchInput = (item) => {
        setInputValue(item)
    }

    const Signout = () => {
        const auth = getAuth();
        signOut(auth).then(() => {
            console.log("signout successfull")
            dispatch(userInfo(null))
            localStorage.removeItem("userLocal")
            alert("Signout Successfull");
            navigate("/login")
        }).catch((error) => {
            // An error happened.
        });

    }
    // var userProfile = "https://lh3.googleusercontent.com/a/ACg8ocJYiNevB_-86oHLtsr-eV_fNTh2QsMnTTQeh1T9PJkWSM8_GSc3=s96-c"
    // setTimeout(() => {
    //     var userProfile = user?.photoURL || "https://via.placeholder.com/150"

    // }, 3000)

    return (
        <div className=' mx-2 mr-4 flex items-center justify-between'>
            <div className='flex items-center justify-between'>
                <div onClick={handleToggle} className=' px-3 py-2 cursor-pointer hover:bg-slate-100'>
                    <img src={menu11} alt="menu" className='w-16 h-12' />

                </div>
                <div>
                    <img src={logo} alt="logo" className='w-64 h-18' />
                </div>
            </div>
            <div className='w-full ml-10'>
                <div className='flex flex-row'>
                    <input type='text' placeholder={languageCon[language11]?.Search} onChange={handleInputChange} value={inputValue} className=' w-[80%] shadow px-6 py-3 rounded-l-full' />
                    <button className='rounded-r-full shadow py-3 px-6 hover:bg-gray-300'><img src={search11} alt='seacrh ' /> </button>
                </div>
                {searchSugestion &&
                    <div className='absolute bg-white px-3 py-2 rounded-lg  w-[54%] '>
                        {searchSuggestionData?.map((item) =>
                            <div key={item} className='hover:bg-gray-100 mb-1 px-1 cursor-pointer' onClick={() => handlesearchInput(item)}>{item}
                            </div>
                        )}

                    </div>}
            </div>
            <div>
                <select className='w-24 h-10 rounded-full shadow px-2 py-2 hover:bg-slate-200 cursor-pointer' onClick={handelLanguageChange}>
                    {languageSelect.map((item) => {
                        return (<option key={item.id} value={item.id}>{item.name}</option>)
                    }
                    )}
                </select>

            </div>
            <div className='ml-3'>
                {user &&
                    <div className=' flex flex-wrap w-40   py-2 items-center'>
                        <img src={userPhoto} alt="user" className='w-10 h-10 rounded-full hover:bg-slate-300 m-1 p-1' />
                        <div className='px-2'>{user?.displayName}</div>
                    </div>}
            </div>
            <div onClick={user ? Signout : () => SignIn} className='flex shadow pl-3 pr-9 py-2 hover:bg-slate-300 cursor-pointer'>{user ? <div className='flex'>{languageCon[language11]?.Logout} <img src={logout11} /></div> : "login"}</div>
        </div>

    )
}

export default Header
