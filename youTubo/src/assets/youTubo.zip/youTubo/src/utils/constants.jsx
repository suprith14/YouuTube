

export const YOUTUBE_API_KEY = 'AIzaSyCMEzVwpv8CdcFwimaXVXuZpxhKairEews';
export const YOUTUBE_API_KEY1 = "AIzaSyAnUUYQvaItZ8zExT5kXAJ5evMwOz6Tn58";
export const YOUTUBE_API_URL = 'https://www.googleapis.com/youtube/v3/search?part=snippet&maxResults=20&regionCode=IN&type=video&key=' + YOUTUBE_API_KEY;


export const VEDIOCATEGORIES_API = 'https://youtube.googleapis.com/youtube/v3/videoCategories?part=snippet&hl=es&regionCode=ES&key=' + YOUTUBE_API_KEY;


